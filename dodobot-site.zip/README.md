# Dodobot Site

Простая информационная страница о боте Dodobot.

## Структура
- `public/index.html` — главная страница
- `public/style.css` — стили
- `.github/workflows/deploy.yml` — автодеплой на сервер
